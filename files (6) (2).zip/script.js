// ========================================
// NAVEGAÇÃO E INTERAÇÕES PRINCIPAIS
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const btnLogin = document.getElementById('btnLogin');
    const btnComecar = document.getElementById('btnComecar');
    const btnIniciarEstudo = document.getElementById('btnIniciarEstudo');
    const btnVerPlanos = document.getElementById('btnVerPlanos');
    const btnAcessarSintaxe = document.getElementById('btnAcessarSintaxe');
    const footerSintaxe = document.getElementById('footerSintaxe');
    const modalLogin = document.getElementById('modalLogin');
    const modalClose = document.querySelector('.modal-close');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    
    // Links de navegação
    const navLinks = document.querySelectorAll('.nav-link');
    
    // ========================================
    // SMOOTH SCROLL
    // ========================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#' && href !== '#home') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
    
    // ========================================
    // MODAL DE LOGIN
    // ========================================
    function abrirModal() {
        modalLogin.classList.add('active');
    }
    
    function fecharModal() {
        modalLogin.classList.remove('active');
    }
    
    if (btnLogin) {
        btnLogin.addEventListener('click', abrirModal);
    }
    
    if (modalClose) {
        modalClose.addEventListener('click', fecharModal);
    }
    
    if (modalLogin) {
        modalLogin.addEventListener('click', function(e) {
            if (e.target === modalLogin) {
                fecharModal();
            }
        });
    }
    
    // ========================================
    // NAVEGAÇÃO PARA SINTAXE
    // ========================================
    function irParaSintaxe() {
        window.location.href = 'sintaxe.html';
    }
    
    if (btnAcessarSintaxe) {
        btnAcessarSintaxe.addEventListener('click', irParaSintaxe);
    }
    
    if (footerSintaxe) {
        footerSintaxe.addEventListener('click', irParaSintaxe);
    }
    
    if (btnIniciarEstudo) {
        btnIniciarEstudo.addEventListener('click', irParaSintaxe);
    }
    
    // ========================================
    // NAVEGAÇÃO PARA PLANOS
    // ========================================
    function irParaPlanos() {
        const planosSection = document.getElementById('planos');
        if (planosSection) {
            planosSection.scrollIntoView({ behavior: 'smooth' });
        }
    }
    
    if (btnComecar) {
        btnComecar.addEventListener('click', irParaPlanos);
    }
    
    if (btnVerPlanos) {
        btnVerPlanos.addEventListener('click', irParaPlanos);
    }
    
    // ========================================
    // MENU MOBILE
    // ========================================
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            const navMenu = document.querySelector('.nav-menu');
            if (navMenu) {
                navMenu.style.display = navMenu.style.display === 'flex' ? 'none' : 'flex';
            }
        });
    }
    
    // ========================================
    // HIGHLIGHT NAVEGAÇÃO ATIVA
    // ========================================
    function atualizarNavAtiva() {
        const sections = document.querySelectorAll('section[id]');
        const scrollY = window.pageYOffset;
        
        sections.forEach(section => {
            const sectionHeight = section.offsetHeight;
            const sectionTop = section.offsetTop - 100;
            const sectionId = section.getAttribute('id');
            
            if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
    
    window.addEventListener('scroll', atualizarNavAtiva);
    
    // ========================================
    // ANIMAÇÕES AO SCROLL
    // ========================================
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Adicionar animação aos cards
    document.querySelectorAll('.benefit-card, .conteudo-card, .plano-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease';
        observer.observe(card);
    });
    
    // ========================================
    // CONTADOR DE ESTATÍSTICAS
    // ========================================
    function animarContador(elemento, valorFinal, duracao = 2000) {
        const inicio = 0;
        const incremento = valorFinal / (duracao / 16);
        let valorAtual = 0;
        
        const timer = setInterval(() => {
            valorAtual += incremento;
            if (valorAtual >= valorFinal) {
                elemento.textContent = valorFinal + (valorFinal === 100 ? '%' : '+');
                clearInterval(timer);
            } else {
                elemento.textContent = Math.floor(valorAtual) + (valorFinal === 100 ? '%' : '+');
            }
        }, 16);
    }
    
    // Animar estatísticas quando visíveis
    const statsObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const statNumber = entry.target.querySelector('.stat-number');
                if (statNumber && !statNumber.classList.contains('animado')) {
                    const texto = statNumber.textContent;
                    const valor = parseInt(texto);
                    if (!isNaN(valor)) {
                        statNumber.classList.add('animado');
                        animarContador(statNumber, valor);
                    }
                }
            }
        });
    }, { threshold: 0.5 });
    
    document.querySelectorAll('.stat-item').forEach(stat => {
        statsObserver.observe(stat);
    });
    
    // ========================================
    // TOAST NOTIFICATIONS
    // ========================================
    function mostrarToast(mensagem, tipo = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${tipo}`;
        toast.textContent = mensagem;
        toast.style.cssText = `
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            padding: 1rem 1.5rem;
            background: ${tipo === 'success' ? '#10b981' : tipo === 'error' ? '#ef4444' : '#3b82f6'};
            color: white;
            border-radius: 0.5rem;
            box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1);
            z-index: 3000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }
    
    // Adicionar animações CSS
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // ========================================
    // FORMULÁRIO DE LOGIN (DEMONSTRAÇÃO)
    // ========================================
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            mostrarToast('Login realizado com sucesso!', 'success');
            fecharModal();
            setTimeout(() => {
                window.location.href = 'sintaxe.html';
            }, 1000);
        });
    }
    
    // ========================================
    // PLANOS - BOTÕES DE ASSINATURA
    // ========================================
    document.querySelectorAll('.plano-card button').forEach(btn => {
        btn.addEventListener('click', function() {
            const planoNome = this.closest('.plano-card').querySelector('h3').textContent;
            if (planoNome.toLowerCase().includes('gratuito')) {
                mostrarToast('Criando conta gratuita...', 'info');
                setTimeout(() => {
                    window.location.href = 'sintaxe.html';
                }, 1500);
            } else {
                mostrarToast(`Redirecionando para pagamento do plano ${planoNome}...`, 'info');
                setTimeout(() => {
                    // Aqui seria integrado com sistema de pagamento
                    alert('Sistema de pagamento será integrado em breve!');
                }, 1500);
            }
        });
    });
    
    // ========================================
    // PROGRESSO DA HERO CARD
    // ========================================
    const heroProgress = document.querySelector('.hero-card .progress-fill');
    if (heroProgress) {
        setTimeout(() => {
            heroProgress.style.width = '0%';
        }, 500);
    }
    
    // ========================================
    // VERIFICAR SE USUÁRIO TEM PROGRESSO SALVO
    // ========================================
    function verificarProgressoSalvo() {
        const progresso = localStorage.getItem('progressoSintaxe');
        if (progresso) {
            const dados = JSON.parse(progresso);
            if (dados.total > 0) {
                const percentual = Math.round((dados.respondidas / dados.total) * 100);
                const heroProgress = document.querySelector('.hero-card .progress-fill');
                const progressText = document.querySelector('.hero-card .progress-text');
                
                if (heroProgress) {
                    heroProgress.style.width = `${percentual}%`;
                }
                if (progressText) {
                    progressText.textContent = `${percentual}% Concluído`;
                }
                
                // Mostrar mensagem de boas-vindas
                setTimeout(() => {
                    mostrarToast(`Bem-vindo de volta! Você já completou ${percentual}% do curso.`, 'success');
                }, 1000);
            }
        }
    }
    
    verificarProgressoSalvo();
    
    console.log('🎓 @TUDOSOBREPORTUGUÊS carregado com sucesso!');
});
