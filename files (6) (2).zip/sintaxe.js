// ========================================
// BANCO DE QUESTÕES - SINTAXE ETAPA 1
// ========================================

const questoesEtapa1 = [
    // NÍVEL 1 - BÁSICO (Questões 1-30)
    {
        id: 1,
        nivel: 1,
        enunciado: '"Silêncio!" é frase, oração ou período? Justifique sua resposta.',
        opcoes: [
            'É uma oração, pois possui verbo implícito',
            'É uma frase nominal, pois não contém verbo',
            'É um período simples sem verbo',
            'É uma frase verbal incompleta',
            'Não é considerada frase por ser muito curta'
        ],
        respostaCorreta: 1,
        explicacao: '"Silêncio!" é uma frase nominal porque transmite uma mensagem completa sem a presença de verbo. Frases nominais são enunciados dotados de sentido completo, mas sem estrutura verbal.'
    },
    {
        id: 2,
        nivel: 1,
        enunciado: 'Analise: "O cachorro latiu a noite toda." Quantas orações há? Qual o verbo?',
        opcoes: [
            'Duas orações; verbos: latir e ser',
            'Uma oração; verbo: latiu',
            'Nenhuma oração, pois é frase nominal',
            'Três orações; verbos: latir, ter e ser',
            'Uma oração; verbo: cachorro'
        ],
        respostaCorreta: 1,
        explicacao: 'Há apenas uma oração, pois existe apenas um verbo: "latiu" (verbo latir conjugado). Para contar orações, contamos os verbos ou locuções verbais presentes na frase.'
    },
    {
        id: 3,
        nivel: 1,
        enunciado: 'Classifique quanto ao tipo: "Que horas são?"',
        opcoes: [
            'Frase declarativa afirmativa',
            'Frase exclamativa',
            'Frase imperativa',
            'Frase interrogativa direta',
            'Frase declarativa negativa'
        ],
        respostaCorreta: 3,
        explicacao: 'É uma frase interrogativa direta, pois faz uma pergunta e termina com ponto de interrogação. Solicita uma informação (as horas) de forma direta.'
    },
    {
        id: 4,
        nivel: 1,
        enunciado: '"Que dia maravilhoso!" É oração? Por quê?',
        opcoes: [
            'Sim, pois contém verbo de ligação implícito',
            'Não, pois não possui verbo ou locução verbal',
            'Sim, pois possui sujeito e predicado',
            'Não, pois é apenas uma interjeição',
            'Sim, pois expressa emoção completa'
        ],
        respostaCorreta: 1,
        explicacao: 'Não é oração porque não há verbo ou locução verbal. Oração é a unidade linguística organizada em torno de um verbo. Esta é uma frase nominal exclamativa.'
    },
    {
        id: 5,
        nivel: 1,
        enunciado: '"Os alunos estudaram e foram aprovados." Classifique o período quanto ao número de orações.',
        opcoes: [
            'Período simples (1 oração)',
            'Período composto (2 orações)',
            'Período composto (3 orações)',
            'Não é período, é apenas frase',
            'Período composto (4 orações)'
        ],
        respostaCorreta: 1,
        explicacao: 'É um período composto com 2 orações: "Os alunos estudaram" (1ª oração) e "foram aprovados" (2ª oração). Há dois verbos, portanto duas orações.'
    },
    {
        id: 6,
        nivel: 1,
        enunciado: 'Identifique o tipo de frase: "Não saia da sala."',
        opcoes: [
            'Declarativa negativa',
            'Interrogativa direta',
            'Imperativa negativa',
            'Exclamativa',
            'Declarativa afirmativa'
        ],
        respostaCorreta: 2,
        explicacao: 'É uma frase imperativa negativa, pois expressa uma ordem ou comando (não saia) com o advérbio de negação "não". Imperativas negativas sempre usam o modo subjuntivo.'
    },
    {
        id: 7,
        nivel: 1,
        enunciado: '"Fogo!" é uma frase completa? Justifique.',
        opcoes: [
            'Não, pois não tem verbo',
            'Sim, pois transmite mensagem completa no contexto',
            'Não, pois é apenas uma palavra',
            'Sim, mas apenas se tiver ponto de exclamação',
            'Não, pois precisa de sujeito'
        ],
        respostaCorreta: 1,
        explicacao: 'Sim, é uma frase completa. Mesmo sem verbo, "Fogo!" transmite uma mensagem completa em contexto (alerta de incêndio), possuindo autonomia comunicativa.'
    },
    {
        id: 8,
        nivel: 1,
        enunciado: 'Conte os verbos: "Maria chegou, sentou-se e começou a trabalhar."',
        opcoes: [
            '2 verbos',
            '3 verbos',
            '4 verbos',
            '5 verbos',
            '1 verbo'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 3 verbos: "chegou", "sentou-se" e "começou". Observe que "começou a trabalhar" é uma locução verbal que conta como 1 verbo apenas. Total: 3 orações.'
    },
    {
        id: 9,
        nivel: 1,
        enunciado: 'Classifique: "Como você está bonita hoje!"',
        opcoes: [
            'Interrogativa direta',
            'Declarativa afirmativa',
            'Exclamativa',
            'Imperativa',
            'Interrogativa indireta'
        ],
        respostaCorreta: 2,
        explicacao: 'É uma frase exclamativa, pois expressa admiração e sentimento através do ponto de exclamação e da palavra exclamativa "Como".'
    },
    {
        id: 10,
        nivel: 1,
        enunciado: '"O professor explicou a matéria." Período simples ou composto? Por quê?',
        opcoes: [
            'Composto, pois tem complemento',
            'Simples, pois tem apenas uma oração (um verbo)',
            'Composto, pois tem sujeito e predicado',
            'Simples, mas com duas orações',
            'Composto, pois a frase é longa'
        ],
        respostaCorreta: 1,
        explicacao: 'É período simples porque possui apenas uma oração (um verbo: "explicou"). Período simples = uma oração; período composto = duas ou mais orações.'
    },
    {
        id: 11,
        nivel: 1,
        enunciado: 'Transforme em interrogativa direta: "Ele chegou cedo."',
        opcoes: [
            'Ele chegou cedo?',
            'Chegou ele cedo?',
            'Cedo ele chegou?',
            'Será que ele chegou cedo.',
            'Como ele chegou cedo!'
        ],
        respostaCorreta: 0,
        explicacao: 'A transformação correta é "Ele chegou cedo?" - basta adicionar o ponto de interrogação e, em alguns casos, ajustar a entonação ou ordem das palavras.'
    },
    {
        id: 12,
        nivel: 1,
        enunciado: '"Atenção!" pode ser considerada oração? Explique.',
        opcoes: [
            'Sim, pois tem sujeito oculto',
            'Não, pois é uma frase nominal sem verbo',
            'Sim, pois expressa uma ação',
            'Não, pois é muito curta',
            'Sim, pois tem predicado'
        ],
        respostaCorreta: 1,
        explicacao: 'Não pode ser considerada oração porque não há verbo. "Atenção!" é uma frase nominal (interjeição) que transmite aviso ou chamada de atenção.'
    },
    {
        id: 13,
        nivel: 1,
        enunciado: 'Classifique o tipo de frase: "Talvez ele venha amanhã."',
        opcoes: [
            'Imperativa',
            'Exclamativa',
            'Interrogativa',
            'Declarativa (afirmativa com dúvida)',
            'Negativa'
        ],
        respostaCorreta: 3,
        explicacao: 'É uma frase declarativa afirmativa que expressa dúvida através do advérbio "talvez". Declara uma possibilidade de forma afirmativa.'
    },
    {
        id: 14,
        nivel: 1,
        enunciado: 'Quantas orações há em: "Quando chegar, me avise."',
        opcoes: [
            '1 oração',
            '2 orações',
            '3 orações',
            '4 orações',
            'Nenhuma oração'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 orações: "Quando chegar" (verbo: chegar) e "me avise" (verbo: avisar). Contamos os verbos para determinar o número de orações.'
    },
    {
        id: 15,
        nivel: 1,
        enunciado: 'Transforme em imperativa: "Você deve estudar mais."',
        opcoes: [
            'Você estuda mais.',
            'Estude mais.',
            'Você estudará mais.',
            'Você estudou mais?',
            'Que você estude mais!'
        ],
        respostaCorreta: 1,
        explicacao: 'A forma imperativa é "Estude mais." - usa o verbo no modo imperativo afirmativo, expressando ordem ou conselho de forma direta.'
    },
    {
        id: 16,
        nivel: 1,
        enunciado: '"Bom dia!" é frase, oração ou apenas expressão?',
        opcoes: [
            'É oração com verbo implícito',
            'É apenas expressão de cumprimento',
            'É frase nominal completa',
            'É período simples',
            'Não é considerado frase'
        ],
        respostaCorreta: 2,
        explicacao: '"Bom dia!" é uma frase nominal completa que funciona como cumprimento. Possui sentido completo no contexto comunicativo, mesmo sem verbo.'
    },
    {
        id: 17,
        nivel: 1,
        enunciado: 'Que tipo de frase é: "Será que vai chover?"',
        opcoes: [
            'Declarativa com dúvida',
            'Exclamativa',
            'Interrogativa direta',
            'Imperativa',
            'Interrogativa indireta'
        ],
        respostaCorreta: 2,
        explicacao: 'É uma frase interrogativa direta, pois faz uma pergunta direta (terminada em ponto de interrogação) expressando dúvida através de "Será que".'
    },
    {
        id: 18,
        nivel: 1,
        enunciado: '"Ele trabalha e estuda." Identifique o número de orações e verbos.',
        opcoes: [
            '1 oração, 1 verbo',
            '2 orações, 2 verbos',
            '3 orações, 3 verbos',
            '2 orações, 1 verbo',
            '1 oração, 2 verbos'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 orações e 2 verbos: "Ele trabalha" (verbo: trabalhar) e "estuda" (verbo: estudar). Cada verbo indica uma oração.'
    },
    {
        id: 19,
        nivel: 1,
        enunciado: 'Transforme em exclamativa: "O filme foi bom."',
        opcoes: [
            'O filme foi bom.',
            'O filme foi bom?',
            'Como o filme foi bom!',
            'O filme não foi bom.',
            'Será que o filme foi bom?'
        ],
        respostaCorreta: 2,
        explicacao: 'A transformação exclamativa é "Como o filme foi bom!" - usa palavra exclamativa (Como) e ponto de exclamação para expressar ênfase e emoção.'
    },
    {
        id: 20,
        nivel: 1,
        enunciado: '"Socorro! Chamem a polícia!" Quantas frases há? Classifique cada uma.',
        opcoes: [
            '1 frase exclamativa',
            '2 frases: ambas exclamativas',
            '2 frases: interrogativa e imperativa',
            '1 frase imperativa',
            '3 frases diferentes'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 frases: "Socorro!" (frase exclamativa nominal) e "Chamem a polícia!" (frase imperativa com valor exclamativo pelo ponto de exclamação).'
    },
    {
        id: 21,
        nivel: 1,
        enunciado: 'Classifique o período: "Saí correndo porque estava atrasado."',
        opcoes: [
            'Período simples',
            'Período composto por coordenação',
            'Período composto por subordinação',
            'Frase nominal',
            'Não é período'
        ],
        respostaCorreta: 2,
        explicacao: 'É período composto por subordinação com 2 orações: "Saí correndo" (principal) e "porque estava atrasado" (subordinada causal).'
    },
    {
        id: 22,
        nivel: 1,
        enunciado: 'Identifique o tipo de frase: "Por favor, me ajude."',
        opcoes: [
            'Declarativa',
            'Interrogativa',
            'Exclamativa',
            'Imperativa (pedido cortês)',
            'Nominal'
        ],
        respostaCorreta: 3,
        explicacao: 'É frase imperativa com tom de pedido cortês, indicado pela expressão "Por favor". Expressa solicitação de forma educada.'
    },
    {
        id: 23,
        nivel: 1,
        enunciado: '"Cuidado com o degrau." Há verbo? É oração? Classifique a frase.',
        opcoes: [
            'Sim, há verbo implícito; é oração imperativa',
            'Não há verbo; é frase nominal de advertência',
            'Sim, há verbo "cuidado"; é oração',
            'Não há verbo; não é frase',
            'Há locução verbal implícita'
        ],
        respostaCorreta: 1,
        explicacao: 'Não há verbo expresso, portanto não é oração. É uma frase nominal que funciona como advertência ou alerta sobre perigo.'
    },
    {
        id: 24,
        nivel: 1,
        enunciado: 'Quantas orações: "Espero que você compreenda a situação."',
        opcoes: [
            '1 oração',
            '2 orações',
            '3 orações',
            'Nenhuma oração',
            '4 orações'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 orações: "Espero" (verbo: esperar) e "que você compreenda a situação" (verbo: compreender). Total de 2 verbos = 2 orações.'
    },
    {
        id: 25,
        nivel: 1,
        enunciado: 'Transforme em declarativa negativa: "Ele está em casa."',
        opcoes: [
            'Ele não está em casa?',
            'Ele não está em casa.',
            'Não esteja em casa!',
            'Ele está em casa?',
            'Como ele não está em casa!'
        ],
        respostaCorreta: 1,
        explicacao: 'A forma declarativa negativa é "Ele não está em casa." - adiciona-se o advérbio de negação "não" antes do verbo.'
    },
    {
        id: 26,
        nivel: 1,
        enunciado: '"Meu Deus!" é que tipo de frase? Justifique.',
        opcoes: [
            'Declarativa',
            'Interrogativa',
            'Exclamativa (invocação)',
            'Imperativa',
            'Não é frase'
        ],
        respostaCorreta: 2,
        explicacao: 'É frase exclamativa que expressa invocação ou súplica. O ponto de exclamação indica a carga emotiva da expressão.'
    },
    {
        id: 27,
        nivel: 1,
        enunciado: 'Analise: "Feche a janela, por favor." (tipo de frase e tom)',
        opcoes: [
            'Interrogativa polida',
            'Declarativa com pedido',
            'Imperativa com tom cortês (pedido)',
            'Exclamativa',
            'Nominal de ordem'
        ],
        respostaCorreta: 2,
        explicacao: 'É frase imperativa (verbo no imperativo: "Feche") com tom cortês indicado por "por favor", transformando a ordem em pedido educado.'
    },
    {
        id: 28,
        nivel: 1,
        enunciado: '"A vida é bela." Classifique o período.',
        opcoes: [
            'Período composto',
            'Período simples',
            'Frase nominal',
            'Período misto',
            'Não é período'
        ],
        respostaCorreta: 1,
        explicacao: 'É período simples porque possui apenas uma oração (um verbo: "é"). Período simples = 1 oração.'
    },
    {
        id: 29,
        nivel: 1,
        enunciado: 'Identifique os verbos e classifique o período: "Quem sabe faz a hora, não espera acontecer."',
        opcoes: [
            '2 verbos; período simples',
            '3 verbos; período composto',
            '4 verbos; período composto',
            '1 verbo; período simples',
            '5 verbos; período complexo'
        ],
        respostaCorreta: 2,
        explicacao: 'Há 4 verbos: "sabe", "faz", "espera" e "acontecer". Portanto, é período composto com 4 orações.'
    },
    {
        id: 30,
        nivel: 1,
        enunciado: 'Transforme em interrogativa indireta: "Onde ele mora?"',
        opcoes: [
            'Onde ele mora.',
            'Gostaria de saber onde ele mora.',
            'Ele mora onde?',
            'Onde mora ele?',
            'Como ele mora!'
        ],
        respostaCorreta: 1,
        explicacao: 'A forma interrogativa indireta é "Gostaria de saber onde ele mora." - a pergunta fica subordinada a um verbo principal, sem ponto de interrogação.'
    },

    // NÍVEL 2 - INTERMEDIÁRIO (Questões 31-60) - Amostra de 10 questões
    {
        id: 31,
        nivel: 2,
        enunciado: '"Que absurdo!" Classifique e explique o valor expressivo.',
        opcoes: [
            'Declarativa que informa um fato',
            'Exclamativa que expressa indignação',
            'Interrogativa que questiona',
            'Imperativa que ordena',
            'Nominal neutra'
        ],
        respostaCorreta: 1,
        explicacao: 'É frase exclamativa que expressa indignação, surpresa negativa ou reprovação. O valor expressivo está na carga emocional de desaprovação.'
    },
    {
        id: 32,
        nivel: 2,
        enunciado: 'Analise: "Se chover, não iremos ao parque." (número de orações e relação)',
        opcoes: [
            '1 oração simples',
            '2 orações com relação de condição',
            '3 orações coordenadas',
            '2 orações sem relação',
            '1 oração composta'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 orações: "Se chover" (subordinada condicional) e "não iremos ao parque" (principal). A relação é de condição: a ida ao parque depende de não chover.'
    },
    {
        id: 33,
        nivel: 2,
        enunciado: '"Psiu!" pode funcionar como frase? Em que contextos?',
        opcoes: [
            'Não, é apenas som sem significado',
            'Sim, em contextos de pedido de silêncio',
            'Só com outras palavras',
            'Apenas em textos escritos',
            'Nunca funciona como frase'
        ],
        respostaCorreta: 1,
        explicacao: 'Sim, "Psiu!" funciona como frase completa em contextos onde se pede silêncio ou atenção. É uma interjeição com sentido comunicativo pleno.'
    },
    {
        id: 34,
        nivel: 2,
        enunciado: 'Compare os tipos de frase: "Nunca mais faça isso" e "Você nunca mais fará isso."',
        opcoes: [
            'Ambas são declarativas',
            'Primeira é imperativa, segunda é declarativa',
            'Ambas são imperativas',
            'Primeira é declarativa, segunda é imperativa',
            'Ambas são exclamativas'
        ],
        respostaCorreta: 1,
        explicacao: 'A primeira é imperativa negativa (ordem: "faça" no imperativo). A segunda é declarativa negativa (afirmação sobre o futuro: "fará" no futuro do indicativo).'
    },
    {
        id: 35,
        nivel: 2,
        enunciado: '"Estudar é importante." Quantos verbos há? É período simples ou composto?',
        opcoes: [
            '2 verbos; período composto',
            '1 verbo; período simples',
            '3 verbos; período composto',
            '0 verbos; frase nominal',
            '1 verbo; período composto'
        ],
        respostaCorreta: 1,
        explicacao: 'Há apenas 1 verbo de ligação: "é". "Estudar" é um verbo no infinitivo substantivado (funciona como substantivo/sujeito). Período simples.'
    },
    {
        id: 36,
        nivel: 2,
        enunciado: '"A noite estava fria e estrelada." Analise a estrutura do período.',
        opcoes: [
            'Período composto com 2 orações',
            'Período simples com 1 oração',
            'Período composto com 3 orações',
            'Frase nominal sem verbo',
            'Período simples com 2 orações'
        ],
        respostaCorreta: 1,
        explicacao: 'É período simples com 1 oração e 1 verbo ("estava"). "Fria e estrelada" são dois adjetivos (predicativos) coordenados, não orações separadas.'
    },
    {
        id: 37,
        nivel: 2,
        enunciado: 'Transforme em exclamativa mantendo o sentido: "Você é muito inteligente."',
        opcoes: [
            'Você é muito inteligente?',
            'Como você é inteligente!',
            'Seja muito inteligente!',
            'Você será muito inteligente.',
            'Quem é muito inteligente?'
        ],
        respostaCorreta: 1,
        explicacao: 'A forma exclamativa que mantém o sentido é "Como você é inteligente!" - usa a palavra exclamativa "Como" para expressar admiração.'
    },
    {
        id: 38,
        nivel: 2,
        enunciado: 'Classifique e analise: "Tomara que ele chegue a tempo."',
        opcoes: [
            'Declarativa que informa',
            'Exclamativa de desejo/esperança',
            'Interrogativa de dúvida',
            'Imperativa de ordem',
            'Nominal sem verbo'
        ],
        respostaCorreta: 1,
        explicacao: 'É frase exclamativa (ou optativa) que expressa desejo ou esperança. "Tomara" indica anseio de que algo ocorra, e o verbo está no subjuntivo.'
    },
    {
        id: 39,
        nivel: 2,
        enunciado: 'Identifique as orações: "Vi que ele não estava bem."',
        opcoes: [
            '1 oração',
            '2 orações',
            '3 orações',
            '4 orações',
            'Nenhuma oração'
        ],
        respostaCorreta: 1,
        explicacao: 'Há 2 orações: "Vi" (oração principal, verbo: ver) e "que ele não estava bem" (oração subordinada substantiva, verbo: estar).'
    },
    {
        id: 40,
        nivel: 2,
        enunciado: '"Ai!" Pode ser considerada frase completa? Em que situações?',
        opcoes: [
            'Nunca é frase completa',
            'Sim, em situações de dor ou surpresa',
            'Só com pontuação especial',
            'Apenas em textos literários',
            'Não, é apenas interjeição'
        ],
        respostaCorreta: 1,
        explicacao: 'Sim, "Ai!" é frase completa em situações de dor, surpresa ou espanto. Como interjeição, possui sentido comunicativo completo no contexto.'
    }
];

// Continua com mais questões...
// (No código completo, incluiria todas as 400 questões)

// ========================================
// SISTEMA DE QUESTÕES E PROGRESSO
// ========================================

let progressoUsuario = {
    etapa1: {
        respondidas: 0,
        corretas: 0,
        nivel1: { respondidas: 0, corretas: 0 },
        nivel2: { respondidas: 0, corretas: 0 },
        nivel3: { respondidas: 0, corretas: 0 }
    },
    total: 0,
    pontuacao: 0
};

// Carregar progresso salvo
function carregarProgresso() {
    const salvo = localStorage.getItem('progressoSintaxe');
    if (salvo) {
        progressoUsuario = JSON.parse(salvo);
    }
}

// Salvar progresso
function salvarProgresso() {
    localStorage.setItem('progressoSintaxe', JSON.stringify(progressoUsuario));
}

// Renderizar questões
function renderizarQuestoes(nivelFiltro = 'todos') {
    const container = document.getElementById('questoesContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    let questoesFiltradas = questoesEtapa1;
    if (nivelFiltro !== 'todos') {
        questoesFiltradas = questoesEtapa1.filter(q => q.nivel === parseInt(nivelFiltro));
    }
    
    questoesFiltradas.forEach((questao, index) => {
        const questaoHTML = criarCardQuestao(questao, index);
        container.innerHTML += questaoHTML;
    });
    
    // Adicionar eventos aos botões
    adicionarEventosQuestoes();
}

// Criar card de questão
function criarCardQuestao(questao, index) {
    const nivelClass = `nivel-${questao.nivel}`;
    const nivelTexto = questao.nivel === 1 ? 'Básico' : questao.nivel === 2 ? 'Intermediário' : 'Avançado';
    
    let opcoesHTML = '';
    questao.opcoes.forEach((opcao, i) => {
        opcoesHTML += `
            <div class="opcao-item" data-questao="${questao.id}" data-opcao="${i}">
                <div class="opcao-letra">${String.fromCharCode(65 + i)}</div>
                <div class="opcao-texto">${opcao}</div>
            </div>
        `;
    });
    
    return `
        <div class="questao-card" id="questao-${questao.id}">
            <div class="questao-header">
                <div class="questao-numero">${questao.id}</div>
                <div class="questao-nivel ${nivelClass}">Nível ${questao.nivel} - ${nivelTexto}</div>
            </div>
            <div class="questao-enunciado">${questao.enunciado}</div>
            <div class="questao-opcoes" id="opcoes-${questao.id}">
                ${opcoesHTML}
            </div>
            <div class="questao-feedback" id="feedback-${questao.id}">
                <div class="feedback-titulo"></div>
                <div class="feedback-explicacao"></div>
            </div>
            <div class="questao-acoes">
                <button class="btn-verificar" data-questao="${questao.id}">Verificar Resposta</button>
                <button class="btn-proxima" data-questao="${questao.id}">Próxima Questão</button>
            </div>
        </div>
    `;
}

// Adicionar eventos
function adicionarEventosQuestoes() {
    // Seleção de opções
    document.querySelectorAll('.opcao-item').forEach(opcao => {
        opcao.addEventListener('click', function() {
            const questaoId = this.dataset.questao;
            // Remover seleção anterior
            document.querySelectorAll(`[data-questao="${questaoId}"].opcao-item`).forEach(op => {
                op.classList.remove('selecionada');
            });
            // Adicionar nova seleção
            this.classList.add('selecionada');
        });
    });
    
    // Botões de verificar
    document.querySelectorAll('.btn-verificar').forEach(btn => {
        btn.addEventListener('click', function() {
            const questaoId = parseInt(this.dataset.questao);
            verificarResposta(questaoId);
        });
    });
    
    // Botões de próxima
    document.querySelectorAll('.btn-proxima').forEach(btn => {
        btn.addEventListener('click', function() {
            const questaoId = parseInt(this.dataset.questao);
            proximaQuestao(questaoId);
        });
    });
}

// Verificar resposta
function verificarResposta(questaoId) {
    const questao = questoesEtapa1.find(q => q.id === questaoId);
    if (!questao) return;
    
    const opcaoSelecionada = document.querySelector(`[data-questao="${questaoId}"].opcao-item.selecionada`);
    if (!opcaoSelecionada) {
        alert('Por favor, selecione uma resposta!');
        return;
    }
    
    const respostaUsuario = parseInt(opcaoSelecionada.dataset.opcao);
    const feedback = document.getElementById(`feedback-${questaoId}`);
    const btnVerificar = document.querySelector(`[data-questao="${questaoId}"].btn-verificar`);
    const btnProxima = document.querySelector(`[data-questao="${questaoId}"].btn-proxima`);
    
    // Marcar resposta correta/incorreta
    const todasOpcoes = document.querySelectorAll(`[data-questao="${questaoId}"].opcao-item`);
    todasOpcoes.forEach((opcao, i) => {
        if (i === questao.respostaCorreta) {
            opcao.classList.add('correta');
        }
        if (i === respostaUsuario && respostaUsuario !== questao.respostaCorreta) {
            opcao.classList.add('incorreta');
        }
        // Desabilitar cliques
        opcao.style.pointerEvents = 'none';
    });
    
    // Mostrar feedback
    const acertou = respostaUsuario === questao.respostaCorreta;
    feedback.classList.add('ativo', acertou ? 'acerto' : 'erro');
    feedback.querySelector('.feedback-titulo').innerHTML = acertou ? 
        '✓ Resposta Correta!' : '✗ Resposta Incorreta';
    feedback.querySelector('.feedback-explicacao').textContent = questao.explicacao;
    
    // Atualizar progresso
    progressoUsuario.etapa1.respondidas++;
    if (acertou) {
        progressoUsuario.etapa1.corretas++;
        progressoUsuario.pontuacao += questao.nivel * 10;
    }
    progressoUsuario.total++;
    
    // Atualizar progresso por nível
    const nivel = `nivel${questao.nivel}`;
    progressoUsuario.etapa1[nivel].respondidas++;
    if (acertou) {
        progressoUsuario.etapa1[nivel].corretas++;
    }
    
    salvarProgresso();
    atualizarInterfaceProgresso();
    
    // Trocar botões
    btnVerificar.style.display = 'none';
    btnProxima.classList.add('ativo');
    
    // Marcar questão como respondida
    document.getElementById(`questao-${questaoId}`).classList.add('respondida');
}

// Próxima questão
function proximaQuestao(questaoId) {
    const proximoCard = document.querySelector(`#questao-${questaoId + 1}`);
    if (proximoCard) {
        proximoCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
        mostrarResultado();
    }
}

// Atualizar interface de progresso
function atualizarInterfaceProgresso() {
    const percentual = Math.round((progressoUsuario.etapa1.respondidas / questoesEtapa1.length) * 100);
    
    // Atualizar barra de progresso
    const progressFill = document.querySelector('.sidebar .progress-fill');
    if (progressFill) {
        progressFill.style.width = `${percentual}%`;
    }
    
    const progressPercentage = document.getElementById('progressPercentage');
    if (progressPercentage) {
        progressPercentage.textContent = `${percentual}%`;
    }
    
    const moduloStatus = document.querySelector('.modulo-status');
    if (moduloStatus) {
        moduloStatus.textContent = `${progressoUsuario.etapa1.respondidas}/${questoesEtapa1.length}`;
    }
}

// Mostrar resultado final
function mostrarResultado() {
    const container = document.getElementById('questoesContainer');
    const resultado = document.getElementById('resultadoContainer');
    
    if (container) container.style.display = 'none';
    if (resultado) {
        resultado.style.display = 'block';
        
        const { respondidas, corretas } = progressoUsuario.etapa1;
        const percentual = Math.round((corretas / respondidas) * 100);
        
        resultado.querySelector('.resultado-pontuacao').textContent = `${percentual}%`;
        resultado.querySelector('.resultado-detalhes').innerHTML = `
            <div class="resultado-stat">
                <div class="resultado-stat-valor">${respondidas}</div>
                <div class="resultado-stat-label">Questões Respondidas</div>
            </div>
            <div class="resultado-stat">
                <div class="resultado-stat-valor">${corretas}</div>
                <div class="resultado-stat-label">Respostas Corretas</div>
            </div>
            <div class="resultado-stat">
                <div class="resultado-stat-valor">${respondidas - corretas}</div>
                <div class="resultado-stat-label">Respostas Erradas</div>
            </div>
        `;
    }
    
    resultado.scrollIntoView({ behavior: 'smooth' });
}

// Filtros de nível
document.querySelectorAll('.filtro-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        renderizarQuestoes(this.dataset.nivel);
    });
});

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    carregarProgresso();
    renderizarQuestoes();
    atualizarInterfaceProgresso();
    
    console.log('📚 Sistema de Exercícios carregado!');
});
